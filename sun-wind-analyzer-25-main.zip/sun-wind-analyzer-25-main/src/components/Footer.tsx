import { Sun, Mail, Github, Twitter, Linkedin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Sun className="h-8 w-8" />
              <span className="text-2xl font-bold">Helios</span>
            </div>
            <p className="text-primary-foreground/80 mb-6 max-w-md">
              Empowering sustainable energy decisions through intelligent mapping 
              and analysis. Discover your renewable energy potential today.
            </p>
            <div className="flex gap-4">
              <Twitter className="h-5 w-5 hover:text-energy-solar cursor-pointer transition-colors" />
              <Linkedin className="h-5 w-5 hover:text-energy-solar cursor-pointer transition-colors" />
              <Github className="h-5 w-5 hover:text-energy-solar cursor-pointer transition-colors" />
              <Mail className="h-5 w-5 hover:text-energy-solar cursor-pointer transition-colors" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              <li><a href="#home" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
              <li><a href="#about" className="hover:text-white transition-colors">About</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              <li><a href="#privacy" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#terms" className="hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#disclaimer" className="hover:text-white transition-colors">Disclaimer</a></li>
            </ul>
          </div>
        </div>

        <hr className="border-primary-foreground/20 my-8" />

        {/* Bottom Section */}
        <div className="flex flex-col sm:flex-row justify-between items-center text-sm text-primary-foreground/60">
          <p>© 2024 Helios Energy Analysis. All rights reserved.</p>
          <p className="mt-2 sm:mt-0">
            Energy estimates are approximations based on available data and modeling.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;