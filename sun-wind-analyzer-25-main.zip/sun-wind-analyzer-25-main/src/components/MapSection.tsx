import { useState } from "react";
import { MapPin, Layers, Info, Settings } from "lucide-react";
import { Button } from "./ui/enhanced-button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

const MapSection = () => {
  const [selectedArea, setSelectedArea] = useState(null);
  const [drawingMode, setDrawingMode] = useState(false);

  return (
    <section id="map" className="py-20 bg-gradient-to-b from-background to-secondary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Interactive Energy Mapping
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Draw an area on the map to analyze solar and wind energy potential. 
            Our AI algorithms will calculate energy generation, costs, and savings in real-time.
          </p>
        </div>

        {/* Map Container */}
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Map Controls Sidebar */}
          <Card className="p-6 space-y-6 h-fit">
            <div>
              <h3 className="text-lg font-semibold mb-4">Map Controls</h3>
              
              <div className="space-y-3">
                <Button 
                  variant={drawingMode ? "solar" : "outline"} 
                  className="w-full justify-start"
                  onClick={() => setDrawingMode(!drawingMode)}
                >
                  <MapPin className="mr-2" />
                  {drawingMode ? "Stop Drawing" : "Draw Area"}
                </Button>

                <Button variant="outline" className="w-full justify-start">
                  <Layers className="mr-2" />
                  Layer Options
                </Button>

                <Button variant="outline" className="w-full justify-start">
                  <Settings className="mr-2" />
                  Map Settings
                </Button>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-3">Quick Analysis</h4>
              <div className="space-y-2">
                <Badge variant="secondary" className="w-full justify-start p-2">
                  Solar Radiation: High
                </Badge>
                <Badge variant="secondary" className="w-full justify-start p-2">
                  Wind Speed: Moderate
                </Badge>
                <Badge variant="secondary" className="w-full justify-start p-2">
                  Terrain: Suitable
                </Badge>
              </div>
            </div>

            <div className="p-4 bg-gradient-card rounded-lg border">
              <div className="flex items-start gap-2">
                <Info className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h5 className="font-medium text-sm mb-1">How it works</h5>
                  <p className="text-sm text-muted-foreground">
                    Click and drag to draw a polygon on the map. Release to analyze the selected area.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Main Map Area */}
          <div className="lg:col-span-3">
            <Card className="overflow-hidden shadow-card">
              {/* Map Placeholder */}
              <div className="aspect-[16/10] bg-gradient-to-br from-energy-wind/20 via-background to-energy-solar/20 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center p-8">
                    <MapPin className="h-16 w-16 text-primary mx-auto mb-4" />
                    <h3 className="text-2xl font-semibold mb-2">Interactive Map Interface</h3>
                    <p className="text-muted-foreground mb-6 max-w-md">
                      The interactive map will load here. Users can draw areas, 
                      view satellite imagery, and get real-time energy analysis.
                    </p>
                    
                    {drawingMode && (
                      <div className="p-4 bg-energy-solar/10 rounded-lg border border-energy-solar/20">
                        <p className="text-energy-solar font-medium">
                          Drawing mode active - Click and drag to select an area
                        </p>
                      </div>
                    )}

                    {/* Placeholder Controls */}
                    <div className="flex gap-2 justify-center mt-6">
                      <Button variant="outline" size="sm">
                        Satellite
                      </Button>
                      <Button variant="outline" size="sm">
                        Terrain
                      </Button>
                      <Button variant="outline" size="sm">
                        Hybrid
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Sample drawn area visualization */}
                <div className="absolute top-20 left-20 w-32 h-24 border-2 border-energy-solar border-dashed rounded opacity-50" />
                
                {/* Map attribution placeholder */}
                <div className="absolute bottom-2 right-2 text-xs text-muted-foreground bg-background/80 px-2 py-1 rounded">
                  © Mapbox © OpenStreetMap
                </div>
              </div>
            </Card>

            {/* Instructions */}
            <div className="mt-4 grid sm:grid-cols-3 gap-4">
              <Card className="p-4 text-center">
                <div className="text-2xl mb-2">1️⃣</div>
                <h4 className="font-medium mb-1">Select Area</h4>
                <p className="text-sm text-muted-foreground">Draw a polygon on the map</p>
              </Card>
              
              <Card className="p-4 text-center">
                <div className="text-2xl mb-2">2️⃣</div>
                <h4 className="font-medium mb-1">Analyze</h4>
                <p className="text-sm text-muted-foreground">AI calculates energy potential</p>
              </Card>
              
              <Card className="p-4 text-center">
                <div className="text-2xl mb-2">3️⃣</div>
                <h4 className="font-medium mb-1">Review Results</h4>
                <p className="text-sm text-muted-foreground">Get detailed insights & costs</p>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MapSection;