import { ArrowRight, MapPin, Zap } from "lucide-react";
import { Button } from "./ui/enhanced-button";
import { Card } from "./ui/card";
import heroImage from "../assets/hero-energy-landscape.jpg";

const HeroSection = () => {
  return (
    <section id="home" className="min-h-screen relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Solar panels and wind turbines on green hills"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/60 to-energy-wind/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[60vh]">
          {/* Left Column - Main Content */}
          <div className="text-center lg:text-left">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6">
              Estimate your{" "}
              <span className="bg-gradient-solar bg-clip-text text-transparent">
                solar
              </span>{" "}
              &{" "}
              <span className="bg-gradient-wind bg-clip-text text-transparent">
                wind
              </span>{" "}
              energy potential
            </h1>
            
            <p className="text-xl sm:text-2xl text-white/90 mb-8 leading-relaxed">
              Draw any area on the map to discover renewable energy opportunities,
              cost savings, and environmental impact in seconds.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
              <Button variant="hero" size="xl" className="group">
                <MapPin className="mr-2 group-hover:rotate-12 transition-transform" />
                Draw an area to get started
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button variant="outline" size="xl" className="text-white border-white/30 hover:bg-white/10">
                <Zap className="mr-2" />
                View Demo
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 text-center lg:text-left">
              <div>
                <div className="text-3xl font-bold text-white mb-1">50k+</div>
                <div className="text-white/70 text-sm">Areas Analyzed</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">$2.5M</div>
                <div className="text-white/70 text-sm">Savings Calculated</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-white mb-1">99.8%</div>
                <div className="text-white/70 text-sm">Accuracy Rate</div>
              </div>
            </div>
          </div>

          {/* Right Column - Feature Cards */}
          <div className="space-y-6">
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 shadow-card">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gradient-solar rounded-lg">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    Instant Energy Estimates
                  </h3>
                  <p className="text-white/80">
                    Get precise solar and wind energy potential calculations 
                    based on location, weather patterns, and terrain analysis.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 shadow-card">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gradient-wind rounded-lg">
                  <MapPin className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    Interactive Mapping
                  </h3>
                  <p className="text-white/80">
                    Draw custom areas directly on the map to analyze 
                    specific regions, properties, or development sites.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20 shadow-card">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-primary rounded-lg">
                  <ArrowRight className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    Financial Analysis
                  </h3>
                  <p className="text-white/80">
                    Compare costs, calculate ROI, and explore financing 
                    options with detailed provider comparisons.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;