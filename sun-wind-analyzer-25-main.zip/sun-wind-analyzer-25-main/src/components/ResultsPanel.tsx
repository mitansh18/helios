import { useState } from "react";
import { TrendingUp, DollarSign, Calendar, Zap, Sun, Wind, BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

const ResultsPanel = () => {
  // Mock data for demonstration
  const energyData = [
    { month: "Jan", solar: 1200, wind: 800, savings: 180 },
    { month: "Feb", solar: 1400, wind: 900, savings: 220 },
    { month: "Mar", solar: 1800, wind: 750, savings: 280 },
    { month: "Apr", solar: 2200, wind: 650, savings: 340 },
    { month: "May", solar: 2600, wind: 600, savings: 390 },
    { month: "Jun", solar: 2800, wind: 550, savings: 420 },
    { month: "Jul", solar: 2900, wind: 500, savings: 430 },
    { month: "Aug", solar: 2700, wind: 580, savings: 410 },
    { month: "Sep", solar: 2300, wind: 700, savings: 360 },
    { month: "Oct", solar: 1900, wind: 850, savings: 310 },
    { month: "Nov", solar: 1500, wind: 950, savings: 250 },
    { month: "Dec", solar: 1100, wind: 1000, savings: 200 },
  ];

  const providerData = [
    { name: "SolarTech Pro", price: "$12,500", warranty: "25 years", efficiency: "22%" },
    { name: "GreenEnergy Solutions", price: "$11,800", warranty: "20 years", efficiency: "21%" },
    { name: "EcoPanel Systems", price: "$13,200", warranty: "25 years", efficiency: "23%" },
    { name: "SunPower Elite", price: "$14,100", warranty: "30 years", efficiency: "24%" },
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Energy Analysis Results
          </h2>
          <p className="text-xl text-muted-foreground">
            Comprehensive analysis for your selected area
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="energy">Energy</TabsTrigger>
            <TabsTrigger value="costs">Costs</TabsTrigger>
            <TabsTrigger value="providers">Providers</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-solar text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium flex items-center gap-2">
                    <Sun className="h-5 w-5" />
                    Solar Potential
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1">2,150 kWh</div>
                  <p className="text-white/80 text-sm">per month average</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-wind text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium flex items-center gap-2">
                    <Wind className="h-5 w-5" />
                    Wind Potential
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1">720 kWh</div>
                  <p className="text-white/80 text-sm">per month average</p>
                </CardContent>
              </Card>

              <Card className="bg-primary text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Monthly Savings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1">$340</div>
                  <p className="text-white/80 text-sm">vs traditional power</p>
                </CardContent>
              </Card>

              <Card className="bg-energy-earth text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    ROI Period
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1">6.2 years</div>
                  <p className="text-white/80 text-sm">payback period</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Stats */}
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Energy Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">Solar Energy</span>
                      <span className="text-energy-solar">75%</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">Wind Energy</span>
                      <span className="text-energy-wind">25%</span>
                    </div>
                    <Progress value={25} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Area Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Area</p>
                      <p className="font-semibold">2.5 acres</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Usable Area</p>
                      <p className="font-semibold">2.1 acres</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Terrain Type</p>
                      <Badge variant="secondary">Flat/Rolling</Badge>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Orientation</p>
                      <Badge variant="secondary">South-facing</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="energy" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Energy Generation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={energyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line
                        type="monotone"
                        dataKey="solar"
                        stroke="hsl(var(--energy-solar))"
                        strokeWidth={3}
                        name="Solar (kWh)"
                      />
                      <Line
                        type="monotone"
                        dataKey="wind"
                        stroke="hsl(var(--energy-wind))"
                        strokeWidth={3}
                        name="Wind (kWh)"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="costs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Savings Projection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={energyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Bar
                        dataKey="savings"
                        fill="hsl(var(--primary))"
                        name="Savings ($)"
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="providers" className="space-y-6">
            <div className="grid gap-4">
              {providerData.map((provider, index) => (
                <Card key={index} className="hover:shadow-card transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-lg mb-2">{provider.name}</h3>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Price: </span>
                            <span className="font-medium">{provider.price}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Warranty: </span>
                            <span className="font-medium">{provider.warranty}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Efficiency: </span>
                            <span className="font-medium">{provider.efficiency}</span>
                          </div>
                        </div>
                      </div>
                      <Badge variant={index === 0 ? "default" : "secondary"}>
                        {index === 0 ? "Recommended" : "Available"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};

export default ResultsPanel;