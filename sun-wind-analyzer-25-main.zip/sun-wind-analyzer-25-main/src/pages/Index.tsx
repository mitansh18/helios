import Navigation from "../components/Navigation";
import HeroSection from "../components/HeroSection";
import MapSection from "../components/MapSection";
import ResultsPanel from "../components/ResultsPanel";
import Footer from "../components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <MapSection />
      <ResultsPanel />
      <Footer />
    </div>
  );
};

export default Index;
